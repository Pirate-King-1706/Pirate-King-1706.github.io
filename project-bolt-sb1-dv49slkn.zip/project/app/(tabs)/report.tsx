import { View, Text, ScrollView, StyleSheet, TouchableOpacity, SafeAreaView, TextInput, Alert } from 'react-native';
import { useState, useRef } from 'react';
import { Camera, Mic, MapPin, Send, Image, Video, CircleStop as StopCircle, Play, Languages, Volume2 } from 'lucide-react-native';

export default function ReportScreen() {
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [description, setDescription] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('en-US');
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);
  const [transcribedText, setTranscribedText] = useState<string>('');
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [hasRecording, setHasRecording] = useState(false);
  const [attachments, setAttachments] = useState<string[]>([]);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const recordingTimer = useRef<NodeJS.Timeout | null>(null);

  const categories = [
    { id: 'roads', name: 'Roads & Traffic', icon: '🚗', color: '#DC2626' },
    { id: 'lighting', name: 'Street Lighting', icon: '💡', color: '#EA580C' },
    { id: 'waste', name: 'Waste Management', icon: '🗑️', color: '#059669' },
    { id: 'parks', name: 'Parks & Recreation', icon: '🌳', color: '#2563EB' },
    { id: 'water', name: 'Water & Drainage', icon: '💧', color: '#0891B2' },
    { id: 'safety', name: 'Public Safety', icon: '🚨', color: '#DC2626' },
  ];

  const languages = [
    { code: 'en-US', name: 'English (US)', flag: '🇺🇸' },
    { code: 'es-ES', name: 'Español', flag: '🇪🇸' },
    { code: 'fr-FR', name: 'Français', flag: '🇫🇷' },
    { code: 'de-DE', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'it-IT', name: 'Italiano', flag: '🇮🇹' },
    { code: 'pt-BR', name: 'Português', flag: '🇧🇷' },
    { code: 'zh-CN', name: '中文', flag: '🇨🇳' },
    { code: 'ja-JP', name: '日本語', flag: '🇯🇵' },
    { code: 'ko-KR', name: '한국어', flag: '🇰🇷' },
    { code: 'ar-SA', name: 'العربية', flag: '🇸🇦' },
  ];

  const handleTakePhoto = () => {
    Alert.alert('Camera', 'Photo capture functionality would be implemented here');
    setAttachments([...attachments, 'photo_' + Date.now()]);
  };

  const handleRecordVideo = () => {
    Alert.alert('Video', 'Video recording functionality would be implemented here');
    setAttachments([...attachments, 'video_' + Date.now()]);
  };

  const handleVoiceRecording = () => {
    if (!showLanguageSelector && !isRecording && !hasRecording) {
      setShowLanguageSelector(true);
      return;
    }

    if (isRecording) {
      // Stop recording
      setIsRecording(false);
      setRecordingDuration(0);
      setHasRecording(true);
      if (recordingTimer.current) {
        clearInterval(recordingTimer.current);
        recordingTimer.current = null;
      }
      
      // Start transcription
      setIsTranscribing(true);
      simulateTranscription();
    } else {
      // Start recording
      setIsRecording(true);
      setRecordingDuration(0);
      recordingTimer.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
    }
  };

  const simulateTranscription = () => {
    // Simulate transcription process
    const sampleTranscriptions = {
      'en-US': "There's a large pothole on Main Street near the intersection with Oak Avenue. It's been there for about a week and it's causing cars to swerve dangerously. The hole is approximately 2 feet wide and quite deep.",
      'es-ES': "Hay un bache grande en la Calle Principal cerca de la intersección con la Avenida Oak. Ha estado ahí por aproximadamente una semana y está causando que los autos se desvíen peligrosamente.",
      'fr-FR': "Il y a un grand nid-de-poule sur la rue Main près de l'intersection avec l'avenue Oak. Il est là depuis environ une semaine et fait que les voitures dévient dangereusement.",
      'de-DE': "Es gibt ein großes Schlagloch in der Main Street in der Nähe der Kreuzung mit der Oak Avenue. Es ist seit etwa einer Woche da und verursacht gefährliche Ausweichmanöver der Autos.",
    };

    setTimeout(() => {
      const transcription = sampleTranscriptions[selectedLanguage as keyof typeof sampleTranscriptions] || sampleTranscriptions['en-US'];
      setTranscribedText(transcription);
      setIsTranscribing(false);
      
      // Auto-fill description if empty
      if (!description) {
        setDescription(transcription);
      }
      
      Alert.alert('Transcription Complete', 'Your voice note has been transcribed and added to the description.');
    }, 2000);
  };

  const handleLanguageSelect = (languageCode: string) => {
    setSelectedLanguage(languageCode);
    setShowLanguageSelector(false);
    // Start recording immediately after language selection
    setTimeout(() => {
      handleVoiceRecording();
    }, 100);
  };

  const handlePlayRecording = () => {
    Alert.alert('Playing Recording', 'Voice note playback would be implemented here');
  };

  const handleDeleteRecording = () => {
    Alert.alert(
      'Delete Recording',
      'Are you sure you want to delete this voice recording?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: () => {
            setHasRecording(false);
            setTranscribedText('');
            setRecordingDuration(0);
          }
        }
      ]
    );
  };

  const handleGetLocation = () => {
    Alert.alert('Location', 'Getting your current location...');
    // Simulate getting location
    setTimeout(() => {
      setLocation({ lat: 40.7128, lng: -74.0060 });
    }, 1000);
  };

  const handleSubmitReport = () => {
    if (!selectedCategory || !description) {
      Alert.alert('Missing Information', 'Please select a category and provide a description');
      return;
    }

    Alert.alert(
      'Report Submitted',
      'Your report has been submitted successfully. You will receive updates on its status.',
      [
        {
          text: 'View My Reports',
          onPress: () => {
            // Navigate to my reports
          }
        },
        {
          text: 'Submit Another',
          onPress: () => {
            setSelectedCategory('');
            setDescription('');
            setAttachments([]);
            setLocation(null);
          }
        }
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Report an Issue</Text>
        <Text style={styles.headerSubtitle}>Help improve your community</Text>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>What type of issue?</Text>
          <View style={styles.categoriesGrid}>
            {categories.map((category) => (
              <TouchableOpacity
                key={category.id}
                style={[
                  styles.categoryCard,
                  selectedCategory === category.id && { 
                    backgroundColor: category.color + '15',
                    borderColor: category.color,
                    borderWidth: 2,
                  }
                ]}
                onPress={() => setSelectedCategory(category.id)}
              >
                <Text style={styles.categoryIcon}>{category.icon}</Text>
                <Text style={[
                  styles.categoryName,
                  selectedCategory === category.id && { color: category.color, fontWeight: '600' }
                ]}>
                  {category.name}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Add Photos or Videos</Text>
          <View style={styles.mediaButtons}>
            <TouchableOpacity style={styles.mediaButton} onPress={handleTakePhoto}>
              <Camera size={24} color="#2563EB" />
              <Text style={styles.mediaButtonText}>Take Photo</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.mediaButton} onPress={handleRecordVideo}>
              <Video size={24} color="#2563EB" />
              <Text style={styles.mediaButtonText}>Record Video</Text>
            </TouchableOpacity>
          </View>

          {attachments.length > 0 && (
            <View style={styles.attachmentsList}>
              {attachments.map((attachment, index) => (
                <View key={index} style={styles.attachmentItem}>
                  {attachment.includes('photo') ? (
                    <Image size={16} color="#059669" />
                  ) : (
                    <Video size={16} color="#059669" />
                  )}
                  <Text style={styles.attachmentText}>
                    {attachment.includes('photo') ? 'Photo' : 'Video'} {index + 1}
                  </Text>
                </View>
              ))}
            </View>
          )}
        </View>

        <View style={styles.section}>
          <View style={styles.voiceSection}>
            <Text style={styles.sectionTitle}>Voice Description</Text>
            
            {showLanguageSelector && (
              <View style={styles.languageSelector}>
                <Text style={styles.languageSelectorTitle}>Select your language:</Text>
                <ScrollView style={styles.languageList} showsVerticalScrollIndicator={false}>
                  {languages.map((language) => (
                    <TouchableOpacity
                      key={language.code}
                      style={[
                        styles.languageOption,
                        selectedLanguage === language.code && styles.selectedLanguageOption
                      ]}
                      onPress={() => handleLanguageSelect(language.code)}
                    >
                      <Text style={styles.languageFlag}>{language.flag}</Text>
                      <Text style={[
                        styles.languageName,
                        selectedLanguage === language.code && styles.selectedLanguageName
                      ]}>
                        {language.name}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>
            )}

            {!showLanguageSelector && (
              <>
                <View style={styles.selectedLanguageDisplay}>
                  <Languages size={16} color="#6B7280" />
                  <Text style={styles.selectedLanguageText}>
                    {languages.find(l => l.code === selectedLanguage)?.name || 'English (US)'}
                  </Text>
                  <TouchableOpacity onPress={() => setShowLanguageSelector(true)}>
                    <Text style={styles.changeLanguageText}>Change</Text>
                  </TouchableOpacity>
                </View>

                <TouchableOpacity 
                  style={[
                    styles.voiceButton,
                    isRecording && { backgroundColor: '#DC2626' },
                    hasRecording && !isRecording && { backgroundColor: '#059669' }
                  ]}
                  onPress={handleVoiceRecording}
                >
                  {isRecording ? (
                    <>
                      <StopCircle size={24} color="#FFFFFF" />
                      <Text style={[styles.voiceButtonText, { color: '#FFFFFF' }]}>
                        Stop Recording ({recordingDuration}s)
                      </Text>
                    </>
                  ) : hasRecording ? (
                    <>
                      <Mic size={24} color="#FFFFFF" />
                      <Text style={[styles.voiceButtonText, { color: '#FFFFFF' }]}>
                        Re-record Voice Note
                      </Text>
                    </>
                  ) : (
                    <>
                      <Mic size={24} color="#2563EB" />
                      <Text style={styles.voiceButtonText}>Record Voice Note</Text>
                    </>
                  )}
                </TouchableOpacity>

                {hasRecording && (
                  <View style={styles.recordingControls}>
                    <TouchableOpacity style={styles.playButton} onPress={handlePlayRecording}>
                      <Play size={16} color="#2563EB" />
                      <Text style={styles.playButtonText}>Play Recording</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.deleteButton} onPress={handleDeleteRecording}>
                      <Text style={styles.deleteButtonText}>Delete</Text>
                    </TouchableOpacity>
                  </View>
                )}

                {isTranscribing && (
                  <View style={styles.transcriptionStatus}>
                    <Text style={styles.transcriptionText}>Transcribing audio...</Text>
                  </View>
                )}

                {transcribedText && !isTranscribing && (
                  <View style={styles.transcriptionResult}>
                    <View style={styles.transcriptionHeader}>
                      <Volume2 size={16} color="#059669" />
                      <Text style={styles.transcriptionTitle}>Transcription:</Text>
                    </View>
                    <Text style={styles.transcriptionContent}>{transcribedText}</Text>
                    <TouchableOpacity 
                      style={styles.useTranscriptionButton}
                      onPress={() => setDescription(transcribedText)}
                    >
                      <Text style={styles.useTranscriptionText}>Use as Description</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </>
            )}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Description</Text>
          <TextInput
            style={styles.textInput}
            placeholder="Describe the issue in detail..."
            multiline
            numberOfLines={4}
            value={description}
            onChangeText={setDescription}
            textAlignVertical="top"
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Location</Text>
          <TouchableOpacity style={styles.locationButton} onPress={handleGetLocation}>
            <MapPin size={24} color="#2563EB" />
            <View style={styles.locationContent}>
              <Text style={styles.locationButtonText}>
                {location ? 'Location Added' : 'Add Current Location'}
              </Text>
              {location && (
                <Text style={styles.locationCoords}>
                  {location.lat.toFixed(6)}, {location.lng.toFixed(6)}
                </Text>
              )}
            </View>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.submitButton} onPress={handleSubmitReport}>
          <Send size={20} color="#FFFFFF" />
          <Text style={styles.submitButtonText}>Submit Report</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    padding: 20,
    paddingBottom: 12,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#6B7280',
  },
  scrollView: {
    flex: 1,
  },
  section: {
    padding: 20,
    paddingTop: 0,
    marginBottom: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 16,
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  categoryCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  categoryIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  categoryName: {
    fontSize: 14,
    fontWeight: '500',
    color: '#374151',
    textAlign: 'center',
  },
  mediaButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  mediaButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  mediaButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#2563EB',
    marginLeft: 8,
  },
  attachmentsList: {
    marginTop: 16,
    gap: 8,
  },
  attachmentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ECFDF5',
    padding: 12,
    borderRadius: 8,
  },
  attachmentText: {
    fontSize: 14,
    color: '#059669',
    fontWeight: '500',
    marginLeft: 8,
  },
  voiceButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  voiceButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#2563EB',
    marginLeft: 8,
  },
  voiceSection: {
    gap: 16,
  },
  languageSelector: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  languageSelectorTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 12,
  },
  languageList: {
    maxHeight: 200,
  },
  languageOption: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 8,
    marginBottom: 4,
  },
  selectedLanguageOption: {
    backgroundColor: '#EBF5FF',
  },
  languageFlag: {
    fontSize: 20,
    marginRight: 12,
  },
  languageName: {
    fontSize: 16,
    color: '#374151',
  },
  selectedLanguageName: {
    color: '#2563EB',
    fontWeight: '600',
  },
  selectedLanguageDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    padding: 12,
    borderRadius: 8,
    gap: 8,
  },
  selectedLanguageText: {
    flex: 1,
    fontSize: 14,
    color: '#374151',
    fontWeight: '500',
  },
  changeLanguageText: {
    fontSize: 14,
    color: '#2563EB',
    fontWeight: '500',
  },
  recordingControls: {
    flexDirection: 'row',
    gap: 12,
  },
  playButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F3F4F6',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  playButtonText: {
    fontSize: 14,
    color: '#2563EB',
    fontWeight: '500',
    marginLeft: 6,
  },
  deleteButton: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#FCA5A5',
    backgroundColor: '#FEF2F2',
  },
  deleteButtonText: {
    fontSize: 14,
    color: '#DC2626',
    fontWeight: '500',
  },
  transcriptionStatus: {
    backgroundColor: '#FEF3C7',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  transcriptionText: {
    fontSize: 14,
    color: '#92400E',
    fontWeight: '500',
  },
  transcriptionResult: {
    backgroundColor: '#ECFDF5',
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#D1FAE5',
  },
  transcriptionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  transcriptionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#059669',
    marginLeft: 6,
  },
  transcriptionContent: {
    fontSize: 14,
    color: '#374151',
    lineHeight: 20,
    marginBottom: 12,
  },
  useTranscriptionButton: {
    backgroundColor: '#059669',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  useTranscriptionText: {
    fontSize: 12,
    color: '#FFFFFF',
    fontWeight: '600',
  },
  textInput: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E5E7EB',
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    minHeight: 120,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  locationButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  locationContent: {
    flex: 1,
    marginLeft: 12,
  },
  locationButtonText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#2563EB',
  },
  locationCoords: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 2,
  },
  submitButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#2563EB',
    margin: 20,
    padding: 18,
    borderRadius: 16,
    shadowColor: '#2563EB',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  submitButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#FFFFFF',
    marginLeft: 8,
  },
});