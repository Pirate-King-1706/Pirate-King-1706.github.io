import { View, Text, ScrollView, StyleSheet, TextInput, TouchableOpacity, SafeAreaView, KeyboardAvoidingView, Platform } from 'react-native';
import { useState, useRef, useEffect } from 'react';
import { Send, Mic, Bot, User, CircleHelp as HelpCircle, FileText, MapPin, Phone, Languages, Volume2 } from 'lucide-react-native';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  type?: 'text' | 'quick_action';
  actions?: QuickAction[];
}

interface QuickAction {
  title: string;
  action: string;
  icon: any;
}

export default function ChatScreen() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hi! I'm your civic assistant. I can help you with reporting issues, tracking reports, and answering questions about city services. I support voice input in multiple languages. How can I assist you today?",
      sender: 'bot',
      timestamp: new Date(),
      type: 'quick_action',
      actions: [
        { title: 'Report New Issue', action: 'report', icon: FileText },
        { title: 'Check Report Status', action: 'status', icon: MapPin },
        { title: 'Get Help', action: 'help', icon: HelpCircle },
        { title: 'Contact Support', action: 'contact', icon: Phone },
      ],
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('en-US');
  const [showLanguageSelector, setShowLanguageSelector] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);

  const languages = [
    { code: 'en-US', name: 'English (US)', flag: '🇺🇸' },
    { code: 'es-ES', name: 'Español', flag: '🇪🇸' },
    { code: 'fr-FR', name: 'Français', flag: '🇫🇷' },
    { code: 'de-DE', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'it-IT', name: 'Italiano', flag: '🇮🇹' },
    { code: 'pt-BR', name: 'Português', flag: '🇧🇷' },
    { code: 'zh-CN', name: '中文', flag: '🇨🇳' },
    { code: 'ja-JP', name: '日本語', flag: '🇯🇵' },
  ];

  useEffect(() => {
    scrollViewRef.current?.scrollToEnd({ animated: true });
  }, [messages]);

  const sendMessage = (text: string) => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');

    // Simulate bot response
    setTimeout(() => {
      const botResponse = getBotResponse(text);
      setMessages(prev => [...prev, botResponse]);
    }, 1000);
  };

  const getBotResponse = (userText: string): Message => {
    const lowerText = userText.toLowerCase();
    
    if (lowerText.includes('pothole') || lowerText.includes('road')) {
      return {
        id: (Date.now() + 1).toString(),
        text: "I understand you're reporting a road issue. To help you submit a detailed report, I'll guide you through the process. Please provide:\n\n1. Exact location or address\n2. Size and severity of the pothole\n3. Any safety concerns\n\nWould you like me to open the reporting form for you?",
        sender: 'bot',
        timestamp: new Date(),
        type: 'quick_action',
        actions: [
          { title: 'Open Report Form', action: 'report', icon: FileText },
          { title: 'Call Emergency', action: 'emergency', icon: Phone },
        ],
      };
    }
    
    if (lowerText.includes('status') || lowerText.includes('track')) {
      return {
        id: (Date.now() + 1).toString(),
        text: "You can check your report status in several ways:\n\n• Visit the 'My Reports' tab to see all your submissions\n• Each report shows its current status: Submitted → Acknowledged → In Progress → Resolved\n• You'll receive push notifications for status updates\n\nWould you like me to take you to your reports?",
        sender: 'bot',
        timestamp: new Date(),
        type: 'quick_action',
        actions: [
          { title: 'View My Reports', action: 'myreports', icon: FileText },
        ],
      };
    }
    
    if (lowerText.includes('light') || lowerText.includes('street')) {
      return {
        id: (Date.now() + 1).toString(),
        text: "Street lighting issues are important for public safety. When reporting a street light problem, please include:\n\n• Street address or nearest intersection\n• Light pole number if visible\n• Nature of the issue (completely out, flickering, dim)\n• How long it's been out\n\nShall I help you submit this report?",
        sender: 'bot',
        timestamp: new Date(),
        type: 'quick_action',
        actions: [
          { title: 'Report Light Issue', action: 'report', icon: FileText },
        ],
      };
    }
    
    return {
      id: (Date.now() + 1).toString(),
      text: "I'm here to help with civic issues and city services. You can:\n\n• Report new issues like potholes, broken lights, or waste problems\n• Track your existing reports\n• Get information about city services\n• Find contact information for different departments\n\nWhat would you like to do?",
      sender: 'bot',
      timestamp: new Date(),
      type: 'quick_action',
      actions: [
        { title: 'Report Issue', action: 'report', icon: FileText },
        { title: 'View Reports', action: 'myreports', icon: MapPin },
        { title: 'Get Help', action: 'help', icon: HelpCircle },
      ],
    };
  };

  const handleQuickAction = (action: string) => {
    switch (action) {
      case 'report':
        sendMessage("I'd like to report a new issue");
        break;
      case 'status':
        sendMessage("Check my report status");
        break;
      case 'help':
        sendMessage("I need help with the app");
        break;
      case 'contact':
        sendMessage("Contact support");
        break;
      case 'myreports':
        sendMessage("Show my reports");
        break;
      case 'emergency':
        sendMessage("This is an emergency situation");
        break;
    }
  };

  const handleVoiceInput = () => {
    if (!showLanguageSelector && !isRecording) {
      setShowLanguageSelector(true);
      return;
    }

    if (isRecording) {
      // Stop recording and transcribe
      setIsRecording(false);
      setIsTranscribing(true);
      
      // Simulate transcription
      setTimeout(() => {
        const sampleMessages = {
          'en-US': "I need to report a pothole on Main Street near the library",
          'es-ES': "Necesito reportar un bache en la Calle Principal cerca de la biblioteca",
          'fr-FR': "Je dois signaler un nid-de-poule sur la rue Main près de la bibliothèque",
          'de-DE': "Ich muss ein Schlagloch in der Main Street in der Nähe der Bibliothek melden",
        };
        
        const transcribedMessage = sampleMessages[selectedLanguage as keyof typeof sampleMessages] || sampleMessages['en-US'];
        setIsTranscribing(false);
        sendMessage(transcribedMessage);
      }, 2000);
    } else {
      // Start recording
      setIsRecording(true);
      setShowLanguageSelector(false);
    }
  };

  const handleLanguageSelect = (languageCode: string) => {
    setSelectedLanguage(languageCode);
    setShowLanguageSelector(false);
    // Start recording immediately after language selection
    setTimeout(() => {
      setIsRecording(true);
    }, 100);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.botAvatar}>
            <Bot size={20} color="#FFFFFF" />
          </View>
          <View>
            <Text style={styles.headerTitle}>Civic Assistant</Text>
            <Text style={styles.headerStatus}>Online • Always here to help</Text>
          </View>
        </View>
      </View>

      <KeyboardAvoidingView 
        style={styles.chatContainer}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={90}
      >
        <ScrollView 
          ref={scrollViewRef}
          style={styles.messagesContainer}
          showsVerticalScrollIndicator={false}
        >
          {messages.map((message) => (
            <View key={message.id} style={styles.messageWrapper}>
              <View style={[
                styles.messageBubble,
                message.sender === 'user' ? styles.userMessage : styles.botMessage
              ]}>
                {message.sender === 'bot' && (
                  <View style={styles.botMessageHeader}>
                    <Bot size={16} color="#2563EB" />
                  </View>
                )}
                
                <Text style={[
                  styles.messageText,
                  message.sender === 'user' ? styles.userMessageText : styles.botMessageText
                ]}>
                  {message.text}
                </Text>

                {message.actions && (
                  <View style={styles.quickActions}>
                    {message.actions.map((action, index) => (
                      <TouchableOpacity
                        key={index}
                        style={styles.quickActionButton}
                        onPress={() => handleQuickAction(action.action)}
                      >
                        <action.icon size={16} color="#2563EB" />
                        <Text style={styles.quickActionText}>{action.title}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                )}
                
                <Text style={[
                  styles.messageTime,
                  message.sender === 'user' ? styles.userMessageTime : styles.botMessageTime
                ]}>
                  {formatTime(message.timestamp)}
                </Text>
              </View>
            </View>
          ))}
        </ScrollView>

        <View style={styles.inputContainer}>
          {showLanguageSelector && (
            <View style={styles.languageSelector}>
              <Text style={styles.languageSelectorTitle}>Select language for voice input:</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.languageList}>
                {languages.map((language) => (
                  <TouchableOpacity
                    key={language.code}
                    style={[
                      styles.languageOption,
                      selectedLanguage === language.code && styles.selectedLanguageOption
                    ]}
                    onPress={() => handleLanguageSelect(language.code)}
                  >
                    <Text style={styles.languageFlag}>{language.flag}</Text>
                    <Text style={[
                      styles.languageName,
                      selectedLanguage === language.code && styles.selectedLanguageName
                    ]}>
                      {language.name}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
          )}

          {isTranscribing && (
            <View style={styles.transcriptionStatus}>
              <Volume2 size={16} color="#2563EB" />
              <Text style={styles.transcriptionText}>Transcribing your message...</Text>
            </View>
          )}

          <View style={styles.inputWrapper}>
            <TextInput
              style={styles.textInput}
              placeholder="Ask me anything about civic services..."
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={500}
              editable={!isRecording && !isTranscribing}
            />
            <TouchableOpacity 
              style={[
                styles.voiceButton,
                isRecording && { backgroundColor: '#DC2626' },
                isTranscribing && { backgroundColor: '#EA580C' }
              ]}
              onPress={handleVoiceInput}
              disabled={isTranscribing}
            >
              {isTranscribing ? (
                <Volume2 size={20} color="#FFFFFF" />
              ) : isRecording ? (
                <Mic size={20} color="#FFFFFF" />
              ) : (
                <Mic size={20} color="#6B7280" />
              )}
            </TouchableOpacity>
          </View>
          <TouchableOpacity 
            style={[
              styles.sendButton,
              (!inputText.trim() || isRecording || isTranscribing) && { opacity: 0.5 }
            ]}
            onPress={() => sendMessage(inputText)}
            disabled={!inputText.trim() || isRecording || isTranscribing}
          >
            <Send size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  botAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#2563EB',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
  },
  headerStatus: {
    fontSize: 12,
    color: '#059669',
    marginTop: 2,
  },
  chatContainer: {
    flex: 1,
  },
  messagesContainer: {
    flex: 1,
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  messageWrapper: {
    marginBottom: 16,
  },
  messageBubble: {
    maxWidth: '85%',
    padding: 16,
    borderRadius: 20,
  },
  userMessage: {
    backgroundColor: '#2563EB',
    alignSelf: 'flex-end',
    borderBottomRightRadius: 8,
  },
  botMessage: {
    backgroundColor: '#FFFFFF',
    alignSelf: 'flex-start',
    borderBottomLeftRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  botMessageHeader: {
    marginBottom: 8,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 24,
  },
  userMessageText: {
    color: '#FFFFFF',
  },
  botMessageText: {
    color: '#111827',
  },
  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 12,
  },
  quickActionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  quickActionText: {
    fontSize: 14,
    color: '#2563EB',
    fontWeight: '500',
    marginLeft: 6,
  },
  messageTime: {
    fontSize: 12,
    marginTop: 8,
  },
  userMessageTime: {
    color: 'rgba(255, 255, 255, 0.7)',
    textAlign: 'right',
  },
  botMessageTime: {
    color: '#9CA3AF',
  },
  inputContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
    gap: 12,
  },
  inputWrapper: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: '#F3F4F6',
    borderRadius: 24,
    paddingHorizontal: 16,
    paddingVertical: 8,
    alignItems: 'flex-end',
    minHeight: 44,
  },
  textInput: {
    flex: 1,
    fontSize: 16,
    color: '#111827',
    maxHeight: 100,
    paddingVertical: 8,
  },
  voiceButton: {
    padding: 8,
    borderRadius: 20,
    marginLeft: 8,
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#2563EB',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#2563EB',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  languageSelector: {
    position: 'absolute',
    bottom: '100%',
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 8,
  },
  languageSelectorTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#111827',
    marginBottom: 12,
  },
  languageList: {
    flexDirection: 'row',
  },
  languageOption: {
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    marginRight: 8,
    minWidth: 80,
  },
  selectedLanguageOption: {
    backgroundColor: '#EBF5FF',
  },
  languageFlag: {
    fontSize: 16,
    marginBottom: 4,
  },
  languageName: {
    fontSize: 12,
    color: '#374151',
    textAlign: 'center',
  },
  selectedLanguageName: {
    color: '#2563EB',
    fontWeight: '600',
  },
  transcriptionStatus: {
    position: 'absolute',
    bottom: '100%',
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EBF5FF',
    padding: 12,
    borderRadius: 8,
    marginBottom: 8,
  },
  transcriptionText: {
    fontSize: 14,
    color: '#2563EB',
    fontWeight: '500',
    marginLeft: 8,
  },
});