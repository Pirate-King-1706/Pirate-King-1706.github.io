import { View, Text, ScrollView, StyleSheet, TouchableOpacity, SafeAreaView } from 'react-native';
import { useState, useEffect } from 'react';
import { Camera, MapPin, FileText, MessageCircle, TriangleAlert as AlertTriangle, Users } from 'lucide-react-native';
import { router } from 'expo-router';

export default function HomeScreen() {
  const [userRole, setUserRole] = useState<'citizen' | 'municipal'>('citizen');
  const [recentReports, setRecentReports] = useState(5);
  const [activeIssues, setActiveIssues] = useState(23);

  const quickActions = [
    {
      title: 'Report Issue',
      icon: Camera,
      color: '#DC2626',
      onPress: () => router.push('/(tabs)/report'),
    },
    {
      title: 'My Reports',
      icon: FileText,
      color: '#2563EB',
      onPress: () => router.push('/(tabs)/myreports'),
    },
    {
      title: 'Get Help',
      icon: MessageCircle,
      color: '#EA580C',
      onPress: () => router.push('/(tabs)/chat'),
    },
  ];

  const issueCategories = [
    { name: 'Roads & Traffic', count: 8, color: '#DC2626' },
    { name: 'Street Lighting', count: 5, color: '#EA580C' },
    { name: 'Waste Management', count: 7, color: '#059669' },
    { name: 'Parks & Recreation', count: 3, color: '#2563EB' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View>
            <Text style={styles.welcomeText}>Welcome back!</Text>
            <Text style={styles.subtitle}>Let's make our community better</Text>
          </View>
          <TouchableOpacity 
            style={styles.roleSwitch}
            onPress={() => setUserRole(userRole === 'citizen' ? 'municipal' : 'citizen')}
          >
            <Users size={20} color="#2563EB" />
            <Text style={styles.roleSwitchText}>
              {userRole === 'citizen' ? 'Switch to Staff' : 'Switch to Citizen'}
            </Text>
          </TouchableOpacity>
        </View>

        {userRole === 'citizen' ? (
          <>
            <View style={styles.statsContainer}>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{recentReports}</Text>
                <Text style={styles.statLabel}>My Reports</Text>
              </View>
              <View style={styles.statCard}>
                <Text style={styles.statNumber}>{activeIssues}</Text>
                <Text style={styles.statLabel}>Active Issues</Text>
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Quick Actions</Text>
              <View style={styles.quickActionsGrid}>
                {quickActions.map((action, index) => (
                  <TouchableOpacity
                    key={index}
                    style={[styles.quickActionCard, { borderLeftColor: action.color }]}
                    onPress={action.onPress}
                  >
                    <View style={[styles.iconContainer, { backgroundColor: action.color + '15' }]}>
                      <action.icon size={24} color={action.color} />
                    </View>
                    <Text style={styles.quickActionTitle}>{action.title}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Issue Categories</Text>
              <View style={styles.categoriesContainer}>
                {issueCategories.map((category, index) => (
                  <View key={index} style={styles.categoryCard}>
                    <View style={styles.categoryHeader}>
                      <Text style={styles.categoryName}>{category.name}</Text>
                      <View style={[styles.categoryBadge, { backgroundColor: category.color }]}>
                        <Text style={styles.categoryCount}>{category.count}</Text>
                      </View>
                    </View>
                    <View style={[styles.categoryIndicator, { backgroundColor: category.color + '20' }]} />
                  </View>
                ))}
              </View>
            </View>
          </>
        ) : (
          <MunicipalDashboard />
        )}

        <View style={styles.section}>
          <View style={styles.alertCard}>
            <AlertTriangle size={20} color="#EA580C" />
            <View style={styles.alertContent}>
              <Text style={styles.alertTitle}>System Maintenance</Text>
              <Text style={styles.alertText}>
                Scheduled maintenance on Sunday 2-4 AM. Some features may be unavailable.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function MunicipalDashboard() {
  const dashboardStats = [
    { label: 'Total Reports', value: '156', color: '#2563EB' },
    { label: 'Pending', value: '23', color: '#EA580C' },
    { label: 'In Progress', value: '45', color: '#059669' },
    { label: 'Resolved Today', value: '12', color: '#16A34A' },
  ];

  return (
    <View style={styles.municipalContainer}>
      <View style={styles.dashboardGrid}>
        {dashboardStats.map((stat, index) => (
          <View key={index} style={styles.dashboardCard}>
            <Text style={[styles.dashboardValue, { color: stat.color }]}>{stat.value}</Text>
            <Text style={styles.dashboardLabel}>{stat.label}</Text>
          </View>
        ))}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Recent Reports</Text>
        <View style={styles.recentReportsContainer}>
          {[1, 2, 3].map((item) => (
            <View key={item} style={styles.reportItem}>
              <View style={styles.reportStatus} />
              <View style={styles.reportContent}>
                <Text style={styles.reportTitle}>Pothole on Main Street</Text>
                <Text style={styles.reportTime}>2 hours ago</Text>
              </View>
              <TouchableOpacity style={styles.assignButton}>
                <Text style={styles.assignButtonText}>Assign</Text>
              </TouchableOpacity>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    paddingTop: 10,
  },
  welcomeText: {
    fontSize: 28,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#6B7280',
  },
  roleSwitch: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  roleSwitchText: {
    fontSize: 12,
    color: '#2563EB',
    fontWeight: '600',
    marginLeft: 6,
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 24,
    gap: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  statNumber: {
    fontSize: 32,
    fontWeight: '700',
    color: '#2563EB',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    color: '#6B7280',
    fontWeight: '500',
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 16,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
  },
  quickActionCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 16,
    borderLeftWidth: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    alignItems: 'center',
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  quickActionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    textAlign: 'center',
  },
  categoriesContainer: {
    gap: 12,
  },
  categoryCard: {
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
  },
  categoryBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  categoryCount: {
    fontSize: 12,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  categoryIndicator: {
    height: 4,
    borderRadius: 2,
  },
  alertCard: {
    flexDirection: 'row',
    backgroundColor: '#FEF3C7',
    padding: 16,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#EA580C',
  },
  alertContent: {
    flex: 1,
    marginLeft: 12,
  },
  alertTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#92400E',
    marginBottom: 4,
  },
  alertText: {
    fontSize: 13,
    color: '#92400E',
  },
  municipalContainer: {
    marginBottom: 20,
  },
  dashboardGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 20,
    gap: 12,
    marginBottom: 24,
  },
  dashboardCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  dashboardValue: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 4,
  },
  dashboardLabel: {
    fontSize: 12,
    color: '#6B7280',
    fontWeight: '500',
    textAlign: 'center',
  },
  recentReportsContainer: {
    gap: 12,
  },
  reportItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  reportStatus: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#EA580C',
    marginRight: 12,
  },
  reportContent: {
    flex: 1,
  },
  reportTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 2,
  },
  reportTime: {
    fontSize: 12,
    color: '#6B7280',
  },
  assignButton: {
    backgroundColor: '#2563EB',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  assignButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
});