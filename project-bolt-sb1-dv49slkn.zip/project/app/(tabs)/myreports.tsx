import { View, Text, ScrollView, StyleSheet, TouchableOpacity, SafeAreaView } from 'react-native';
import { useState } from 'react';
import { CircleCheck as CheckCircle, Clock, CircleAlert as AlertCircle, Eye, MessageSquare, Calendar } from 'lucide-react-native';

interface Report {
  id: string;
  title: string;
  category: string;
  status: 'submitted' | 'acknowledged' | 'in_progress' | 'resolved';
  priority: 'low' | 'medium' | 'high';
  submittedAt: string;
  lastUpdate: string;
  description: string;
  images: number;
  hasVoiceNote: boolean;
}

export default function MyReportsScreen() {
  const [selectedTab, setSelectedTab] = useState<'active' | 'resolved'>('active');

  const reports: Report[] = [
    {
      id: '1',
      title: 'Pothole on Main Street',
      category: 'Roads & Traffic',
      status: 'in_progress',
      priority: 'high',
      submittedAt: '2 days ago',
      lastUpdate: '5 hours ago',
      description: 'Large pothole causing traffic issues and potential vehicle damage.',
      images: 2,
      hasVoiceNote: true,
    },
    {
      id: '2',
      title: 'Broken Street Light',
      category: 'Street Lighting',
      status: 'acknowledged',
      priority: 'medium',
      submittedAt: '1 week ago',
      lastUpdate: '3 days ago',
      description: 'Street light has been flickering and completely out for 3 days.',
      images: 1,
      hasVoiceNote: false,
    },
    {
      id: '3',
      title: 'Park Bench Vandalized',
      category: 'Parks & Recreation',
      status: 'resolved',
      priority: 'low',
      submittedAt: '2 weeks ago',
      lastUpdate: '5 days ago',
      description: 'Bench has graffiti and needs cleaning or replacement.',
      images: 3,
      hasVoiceNote: true,
    },
    {
      id: '4',
      title: 'Overflowing Storm Drain',
      category: 'Water & Drainage',
      status: 'submitted',
      priority: 'high',
      submittedAt: '1 day ago',
      lastUpdate: '1 day ago',
      description: 'Storm drain is completely blocked and water is backing up.',
      images: 2,
      hasVoiceNote: false,
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'submitted': return '#EA580C';
      case 'acknowledged': return '#2563EB';
      case 'in_progress': return '#7C3AED';
      case 'resolved': return '#059669';
      default: return '#6B7280';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'submitted': return AlertCircle;
      case 'acknowledged': return Eye;
      case 'in_progress': return Clock;
      case 'resolved': return CheckCircle;
      default: return AlertCircle;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return '#DC2626';
      case 'medium': return '#EA580C';
      case 'low': return '#059669';
      default: return '#6B7280';
    }
  };

  const getStatusProgress = (status: string) => {
    switch (status) {
      case 'submitted': return 25;
      case 'acknowledged': return 50;
      case 'in_progress': return 75;
      case 'resolved': return 100;
      default: return 0;
    }
  };

  const filteredReports = reports.filter(report => 
    selectedTab === 'active' ? report.status !== 'resolved' : report.status === 'resolved'
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Reports</Text>
        <Text style={styles.headerSubtitle}>Track your submissions</Text>
      </View>

      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'active' && styles.activeTab]}
          onPress={() => setSelectedTab('active')}
        >
          <Text style={[styles.tabText, selectedTab === 'active' && styles.activeTabText]}>
            Active ({reports.filter(r => r.status !== 'resolved').length})
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, selectedTab === 'resolved' && styles.activeTab]}
          onPress={() => setSelectedTab('resolved')}
        >
          <Text style={[styles.tabText, selectedTab === 'resolved' && styles.activeTabText]}>
            Resolved ({reports.filter(r => r.status === 'resolved').length})
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {filteredReports.map((report) => {
          const StatusIcon = getStatusIcon(report.status);
          return (
            <View key={report.id} style={styles.reportCard}>
              <View style={styles.reportHeader}>
                <View style={styles.statusContainer}>
                  <StatusIcon size={16} color={getStatusColor(report.status)} />
                  <Text style={[styles.statusText, { color: getStatusColor(report.status) }]}>
                    {report.status.replace('_', ' ').toUpperCase()}
                  </Text>
                </View>
                <View style={[styles.priorityBadge, { backgroundColor: getPriorityColor(report.priority) }]}>
                  <Text style={styles.priorityText}>{report.priority}</Text>
                </View>
              </View>

              <Text style={styles.reportTitle}>{report.title}</Text>
              <Text style={styles.reportCategory}>{report.category}</Text>
              <Text style={styles.reportDescription} numberOfLines={2}>
                {report.description}
              </Text>

              <View style={styles.progressContainer}>
                <View style={styles.progressBar}>
                  <View 
                    style={[
                      styles.progressFill, 
                      { 
                        width: `${getStatusProgress(report.status)}%`,
                        backgroundColor: getStatusColor(report.status)
                      }
                    ]} 
                  />
                </View>
                <Text style={styles.progressText}>
                  {getStatusProgress(report.status)}% Complete
                </Text>
              </View>

              <View style={styles.mediaIndicators}>
                {report.images > 0 && (
                  <View style={styles.mediaIndicator}>
                    <Eye size={14} color="#6B7280" />
                    <Text style={styles.mediaText}>{report.images} photo{report.images !== 1 ? 's' : ''}</Text>
                  </View>
                )}
                {report.hasVoiceNote && (
                  <View style={styles.mediaIndicator}>
                    <MessageSquare size={14} color="#6B7280" />
                    <Text style={styles.mediaText}>Voice note</Text>
                  </View>
                )}
              </View>

              <View style={styles.reportFooter}>
                <View style={styles.timeContainer}>
                  <Calendar size={14} color="#9CA3AF" />
                  <Text style={styles.timeText}>Submitted {report.submittedAt}</Text>
                </View>
                <Text style={styles.updateText}>Updated {report.lastUpdate}</Text>
              </View>

              <View style={styles.actionButtons}>
                <TouchableOpacity style={styles.actionButton}>
                  <Text style={styles.actionButtonText}>View Details</Text>
                </TouchableOpacity>
                {report.status !== 'resolved' && (
                  <TouchableOpacity style={[styles.actionButton, styles.secondaryButton]}>
                    <Text style={[styles.actionButtonText, styles.secondaryButtonText]}>
                      Add Comment
                    </Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          );
        })}

        {filteredReports.length === 0 && (
          <View style={styles.emptyState}>
            <FileText size={48} color="#9CA3AF" />
            <Text style={styles.emptyStateTitle}>
              No {selectedTab} reports
            </Text>
            <Text style={styles.emptyStateText}>
              {selectedTab === 'active' 
                ? 'All your reports have been resolved!' 
                : 'Submit your first report to get started'
              }
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    padding: 20,
    paddingBottom: 12,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#6B7280',
  },
  tabContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
    backgroundColor: '#F3F4F6',
    borderRadius: 12,
    margin: 20,
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#6B7280',
  },
  activeTabText: {
    color: '#2563EB',
    fontWeight: '600',
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 20,
  },
  reportCard: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  reportHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 6,
  },
  priorityBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  priorityText: {
    fontSize: 11,
    fontWeight: '700',
    color: '#FFFFFF',
    textTransform: 'uppercase',
  },
  reportTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
    marginBottom: 4,
  },
  reportCategory: {
    fontSize: 14,
    color: '#2563EB',
    fontWeight: '500',
    marginBottom: 8,
  },
  reportDescription: {
    fontSize: 14,
    color: '#6B7280',
    lineHeight: 20,
    marginBottom: 16,
  },
  progressContainer: {
    marginBottom: 16,
  },
  progressBar: {
    height: 6,
    backgroundColor: '#E5E7EB',
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 6,
  },
  progressFill: {
    height: '100%',
    borderRadius: 3,
  },
  progressText: {
    fontSize: 12,
    color: '#6B7280',
    fontWeight: '500',
  },
  mediaIndicators: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 16,
  },
  mediaIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  mediaText: {
    fontSize: 12,
    color: '#6B7280',
    marginLeft: 4,
  },
  reportFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#F3F4F6',
  },
  timeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  timeText: {
    fontSize: 12,
    color: '#9CA3AF',
    marginLeft: 4,
  },
  updateText: {
    fontSize: 12,
    color: '#9CA3AF',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#2563EB',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  secondaryButton: {
    backgroundColor: '#F3F4F6',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  secondaryButtonText: {
    color: '#374151',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#9CA3AF',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#9CA3AF',
    textAlign: 'center',
    lineHeight: 24,
  },
});